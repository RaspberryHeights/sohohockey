# eztext
For writing stuff within pygame

The code was taken from http://www.pygame.org/project-EzText-920-.html

The modifications in the comments are added as well as the suggested ones that had not yet been implemented.

There is a  cx freeze problem, it arises when the pygame font is defined as None, 
in which case a specific font has to be defined in order to avoid the error.

Also make sure you have the font (the Times_New_Roman.ttf) in the same directory where eztext.py is!

I am not loading it, you should be able to find it in your computer :)